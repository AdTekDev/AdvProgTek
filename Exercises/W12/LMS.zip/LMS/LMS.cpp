﻿// LMS.cpp : Defines the entry point for the application.
//

#include "LMS.h"

using namespace std;

#include "People/Person.h"
#include "Content/Course.h"

int main() {
    Person p1("Nguyen Van A", 30);
    Course c1("C++ Programming", 40);

    p1.printInfo();
    c1.printInfo();

    return 0;
}

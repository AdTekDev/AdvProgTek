#include "Course.h"
#include <iostream>

Course::Course(const std::string& title, int duration)
    : title_(title), duration_(duration) {}

std::string Course::getTitle() const {
    return title_;
}

int Course::getDuration() const {
    return duration_;
}

void Course::setTitle(const std::string& title) {
    title_ = title;
}

void Course::setDuration(int duration) {
    duration_ = duration;
}

void Course::printInfo() const {
    std::cout << "Course: " << title_ << ", Duration: " << duration_ << " hours\n";
}

#pragma once
#include <string>

class Course {
public:
    Course(const std::string& title, int duration);

    std::string getTitle() const;
    int getDuration() const; // duration in hours

    void setTitle(const std::string& title);
    void setDuration(int duration);

    void printInfo() const;

private:
    std::string title_;
    int duration_;
};

